Turbo Everdrive USB Tools — build Linux x86_64 (CLI + émulateur)
==================================================================

(English version: README-EN.txt)

Cible : x86_64-unknown-linux-musl (statique — aucune dépendance système,
        fonctionne sur toute distribution x86_64 récente : Ubuntu, Debian,
        Fedora, Arch, Alpine...)

CONTENU DU DOSSIER
  edlink-cli          Ligne de commande (edlink-cli --help)
  edlink-emulator     Émulateur virtuel (tests sans matériel)
  README.txt          Ce fichier

PAS D'INTERFACE GRAPHIQUE DANS CETTE BUILD
  edlink-app (l'interface graphique Tauri) nécessite webkit2gtk et GTK3 pour
  compiler et s'exécuter sous Linux — une cross-compilation depuis macOS ne
  suffit pas (il faut les bibliothèques de développement Linux elles-mêmes,
  pas juste un compilateur croisé). Cette build Linux ne contient donc que
  les outils en ligne de commande.

  Pour obtenir l'interface graphique sous Linux :
    1. Sur une machine Linux (ou un conteneur), installez les dépendances :
         # Debian/Ubuntu
         sudo apt install libwebkit2gtk-4.1-dev build-essential curl wget \
           file libxdo-dev libssl-dev libayatana-appindicator3-dev librsvg2-dev
    2. cargo build --release -p edlink-app
       (voir README.md du dépôt pour le détail des prérequis Tauri)

UTILISATION (CLI)
  chmod +x edlink-cli edlink-emulator   # si les permissions ne sont pas conservées
  ./edlink-cli --help
  ./edlink-emulator --sd ~/SD_PCE

  Voir le README du dépôt pour la liste complète des commandes :
  https://github.com/beddy70/USB-Tools-GUI

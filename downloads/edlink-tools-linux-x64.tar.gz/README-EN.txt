Turbo Everdrive USB Tools - Linux x86_64 build (CLI + emulator)
==================================================================

(Version française : README.txt)

Target: x86_64-unknown-linux-musl (static - no system dependency, works on
        any recent x86_64 distribution: Ubuntu, Debian, Fedora, Arch,
        Alpine...)

FOLDER CONTENTS
  edlink-cli          Command line (edlink-cli --help)
  edlink-emulator     Virtual emulator (hardware-less testing)
  README.txt          This file (French)
  README-EN.txt       This file (English)

NO GRAPHICAL INTERFACE IN THIS BUILD
  edlink-app (the Tauri graphical interface) needs webkit2gtk and GTK3 to
  build and run on Linux - cross-compiling from macOS isn't enough (you
  need the Linux development libraries themselves, not just a cross
  compiler). This Linux build therefore only contains the command-line
  tools.

  To get the graphical interface on Linux:
    1. On a Linux machine (or a container), install the dependencies:
         # Debian/Ubuntu
         sudo apt install libwebkit2gtk-4.1-dev build-essential curl wget \
           file libxdo-dev libssl-dev libayatana-appindicator3-dev librsvg2-dev
    2. cargo build --release -p edlink-app
       (see the repository's README.md for the full Tauri requirements)

USAGE (CLI)
  chmod +x edlink-cli edlink-emulator   # if permissions weren't preserved
  ./edlink-cli --help
  ./edlink-emulator --sd ~/SD_PCE

  See the repository's README for the full command list:
  https://github.com/beddy70/USB-Tools-GUI

Turbo Everdrive USB Tools GUI — build macOS Apple Silicon (arm64)
============================================================

(English version: README-EN.txt)

Version : voir --version ou le bas de la barre latérale de l'application.
Cible   : aarch64-apple-darwin (natif, Apple Silicon M1/M2/M3/M4)

CONTENU DU DOSSIER
  edlink-app          Interface graphique
  edlink-cli          Ligne de commande (edlink-cli --help)
  edlink-emulator     Émulateur virtuel (tests sans matériel)
  README.txt          Ce fichier (français)
  README-EN.txt       Ce fichier (anglais)
  GUIDE_UTILISATEUR.md     Guide pas à pas pour l'application (français)
  GUIDE_UTILISATEUR.en.md  Guide pas à pas pour l'application (anglais)
  qa-checklist.html   Grille de test à ouvrir dans un navigateur

PREMIER LANCEMENT (binaires non signés/notarisés)
  macOS Gatekeeper bloque par défaut un exécutable téléchargé et non signé.
  Pour lancer edlink-app la première fois :
    1. Clic droit sur edlink-app dans le Finder -> Ouvrir -> confirmer
       "Ouvrir quand même" (une seule fois, macOS s'en souvient ensuite) ;
    2. ou, dans un terminal, dans ce dossier :
         xattr -d com.apple.quarantine edlink-app
       (retire l'attribut de quarantaine posé par le navigateur/téléchargement)
  edlink-cli et edlink-emulator sont des outils en ligne de commande : lancez-
  les depuis un terminal (chmod +x déjà appliqué dans ce zip).

UTILISATION
  Voir GUIDE_UTILISATEUR.md pour un guide complet, ou le README du dépôt :
  https://github.com/beddy70/USB-Tools-GUI

  - Branchez la cartouche en USB, affichez le menu de la carte.
  - Lancez edlink-app, choisissez le port série, Connecter.
  - Pour l'émulateur virtuel : lancez edlink-emulator dans un terminal, il
    affiche un chemin de port virtuel (/dev/ttysXXX) à saisir dans le champ
    "Port manuel" de l'application.

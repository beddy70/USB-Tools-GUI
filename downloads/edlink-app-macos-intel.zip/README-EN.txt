Turbo Everdrive USB Tools GUI - macOS Intel (x86_64) build
============================================================

(Version française : README.txt)

Version: see --version or the bottom of the app's sidebar.
Target : x86_64-apple-darwin (native, no Rosetta emulation needed)

FOLDER CONTENTS
  edlink-app          Graphical interface
  edlink-cli          Command line (edlink-cli --help)
  edlink-emulator     Virtual emulator (hardware-less testing)
  README.txt          This file (French)
  README-EN.txt       This file (English)
  GUIDE_UTILISATEUR.md     Step-by-step guide for the app (French)
  GUIDE_UTILISATEUR.en.md  Step-by-step guide for the app (English)
  qa-checklist.html   Test checklist to open in a browser

FIRST LAUNCH (unsigned/non-notarized binaries)
  macOS Gatekeeper blocks a downloaded, unsigned executable by default.
  To launch edlink-app the first time:
    1. Right-click edlink-app in Finder -> Open -> confirm "Open Anyway"
       (only needed once, macOS remembers afterward); or
    2. in a terminal, in this folder:
         xattr -d com.apple.quarantine edlink-app
       (removes the quarantine attribute set by the browser/download)
  edlink-cli and edlink-emulator are command-line tools: run them from a
  terminal (chmod +x already applied in this zip).

USAGE
  See GUIDE_UTILISATEUR.en.md for a full guide, or the repository's README:
  https://github.com/beddy70/USB-Tools-GUI

  - Plug the cartridge in via USB, display the cartridge's menu.
  - Launch edlink-app, choose the serial port, Connect.
  - For the virtual emulator: launch edlink-emulator in a terminal, it
    prints a virtual port path (/dev/ttysXXX) to enter in the app's
    "Manual port" field.

Turbo Everdrive USB Tools GUI - Windows x86_64 build
=====================================================

(Version française : README.txt)

Version : 0.1.1-alpha (milestone M2)
Target  : x86_64-pc-windows-gnu (PE32+)

The exact version (number + git hash + date) is shown at the bottom of the
app's sidebar and by "edlink-emulator.exe --version".

FOLDER CONTENTS
  edlink-app.exe        Graphical interface (Tauri / WebView2)
  edlink-cli.exe        Command line (see READ-ME.txt)
  WebView2Loader.dll    Required next to edlink-app.exe
  README.txt            This file (French)
  README-EN.txt         This file (English)
  LISEZ-MOI.txt         edlink-cli.exe help (French)
  READ-ME.txt           edlink-cli.exe help (English)
  GUIDE_UTILISATEUR.md     Step-by-step guide for the app (French)
  GUIDE_UTILISATEUR.en.md  Step-by-step guide for the app (English)

REQUIREMENTS
  - Windows 10/11 64-bit.
  - WebView2 Runtime: preinstalled on recent Windows 10/11
    (otherwise: https://developer.microsoft.com/microsoft-edge/webview2/).

USAGE
  - Keep edlink-app.exe and WebView2Loader.dll in the same folder.
  - Launch edlink-app.exe.
  - Connection: plug the Turbo EverDrive in via USB, choose the COM port
    (or "auto"), click Connect. For the virtual EdLink emulator, enter the
    port in the "Manual port" field.

WHAT'S IN THIS VERSION (M2)
  - "SD Card" tab: explorer (listing via the Pro firmware's FS protocol),
    upload/download with a progress bar, responsive interface.
  - Simplified Play tab: "Choose and launch..." deploys then directly
    launches the ROM.
  - Console reset, menu screen capture.
  - Memory viewer (read-only).
      RAM: on real hardware, every read walks the cartridge bus and briefly
        freezes the PC-Engine CPU -> conservative mode (small blocks,
        on-demand read via "Refresh"). Unrestricted on the emulator.
      VRAM / CRAM: snapshot via the cartridge menu (*v command, like the
        screen capture) -> display the cartridge menu, not during a game.
  - Sprites tab: sheet of tiles decoded from VRAM (8x8 background or the
    VDC's 6 sprite sizes, 16x16 to 32x64), palette choice, zoom; click ->
    VRAM address, or drag to select a range (PNG export of just the
    selection; "Esc" or the dedicated button clears it).
  - The screen capture no longer re-reads the cartridge when you move a
    setting: it's a software rendering of the tile plane (no sprites, no
    per-line effects).
  - Important fix: any save/download (SD, screen capture, memory dump,
    sprite export) had been silently failing since the very first version
    (a Tauri argument bug). Fixed in this build.
  - Sprites: "Lock" button -> crops the view to just the selection (the
    rest of VRAM is hidden). Handy for tracking a sprite across several
    "Capture" clicks (animation) without losing it in the sheet; the
    selection stays on the same VRAM area even when changing the cell
    size or the number of columns.

NEW (09/02)
  - New Connection tab card: "Mobile access" - starts a small local web
    server giving access, from a smartphone's browser on the same Wi-Fi
    network, to a simplified version of the GAMES tab (categories, boxart
    mosaic, detail sheet with title screen/in-game snapshot alternating,
    launching a game). Address shown as text + a scannable QR code. No
    authentication - trusted local network only, never expose on the
    Internet.
  - Favorites: now a state shared between the desktop and the mobile
    server (persisted to disk) - a game favorited from the phone shows up
    immediately in the desktop's Favorites category, and vice versa.
  - FIX: the "Launch" button on the detail sheet (mobile version) launched
    nothing (an execution-order bug sent an empty path to the server).

NEW (08/31)
  - The interface is now available in French, English, German and Spanish
    (language selector, top right).
  - GAMES: new boxart source to choose from, alongside the network
    (Libretro Thumbnails) - a local "DB_Thumbnails" folder picked on disk
    (folder button next to the dropdown), works fully offline, with the
    Named_Boxarts/Named_Snaps/Named_Titles structure.
  - GAMES: virtual "GAMES" category that shows up automatically when the
    base folder has no category subfolder (direct access to ROMs placed at
    the root, no more blocking error message).
  - GAMES: new favorite (heart) button in a game's detail sheet - a virtual
    "Favorites" category is always shown at the top of the list, grouping
    marked games regardless of their real category.

NEW (08/28 - part 20)
  - Game detail sheet: now alternates the title screen and the in-game
    snapshot every 2 seconds when both are available (badge showing
    which one is displayed).
  - Emulator (dev/tests, outside the Windows build): no longer repeats the
    disconnection message in a loop.

NEW (08/28 - part 22)
  - Detail sheet: "That's the right game" button when the boxart comes
    from a fuzzy match - remembers the found title for this file (100%
    confidence afterward, without going through fuzzy search again). The
    banner stays displayed while the mouse is over it.

NEW/FIX (08/28 - part 21)
  - Detail sheet: the "approximate boxart" warning now clears itself
    after 3s instead of staying displayed permanently.
  - Title screen/snapshot alternation set to 2s (instead of 1s).
  - qa-checklist.html: keeps the original attached image (no more
    automatic resizing/JPEG re-encoding).
  - New: docs/GUIDE_UTILISATEUR.md, a step-by-step guide for the end user
    (installation, each tab in detail, common troubleshooting) - French.

FIX (08/28 - part 19)
  - Boxart: fuzzy search now also separately compares each side of a
    "Main - Subtitle" title (very common on Japanese PC Engine) - the ROM
    dump's name often matches only one of the two sides. Also fixes a
    false-positive risk on a short common word shared by several
    different games.

FIX (08/28 - part 18)
  - Boxart: fixes Japanese titles prefixed on the Libretro side (e.g.
    "Cyber Cross (J).pce" -> "Busou Keiji - Cyber Cross (Japan)", not
    found before, found at 100% now). Percentage badge now permanently
    visible on the thumbnail (not just on hover) when it isn't an exact
    match.

NEW (08/28 - part 17)
  - Boxart: fuzzy (closest) search, scored as a %, as a fallback when no
    exact name variant matches - against the full Libretro database
    index, minimum 80% similarity threshold. The detail sheet shows the
    found title and its score when it isn't an exact match, with a
    pointer to the gear icon (manual mapping) in case of error.

FIX (08/28 - part 16)
  - GAMES: the detail sheet's "Play" button launched nothing - a
    duplicated "sd:/" path (sd:/sd:/...) was built by mistake. Fixed and
    verified against the emulator.

NEW/FIX (08/28 - part 15)
  - GAMES: category rows reduced by 30%.
  - GAMES: fixes a bug where boxart disappeared (controller icon only)
    when revisiting an already-seen category.
  - GAMES: gear-icon button (hover a thumbnail) to manually match a
    not-found game to an exact title from the boxart database (Libretro
    Thumbnails). Remembered for next time.

NEW (08/28 - part 14)
  - GAMES becomes a full-fledged tab (controller icon, right below
    Connection) instead of a view inside SD Card.
  - Fixes a game's detail sheet: the screenshot was cropped (height too
    limited) - now fully visible.

FIX (08/28 - part 13)
  - Games view: the mosaic now reuses its category's color gradient
    (instead of the dark background) - text/button adjusted to stay
    readable.

NEW (08/28 - part 12)
  - "Games" view (game-card button) reworked: configurable base folder
    (default sd:/GAMES, remembered), expected tree
    sd:/GAMES/<Category>/<ROM>. List of categories as colorful rows
    (Recalbox-style), large text; click a category -> mosaic of games
    with boxart, click a game -> detail sheet (Play/Download). "Change
    games folder" button to change the path.

NEW (08/28 - part 11)
  - SD Card carousel: new "coverflow" style (like EmulationStation/
    Batocera) - the middle boxart is highlighted, the side ones are
    scaled down and dimmed. Arrow navigation, click a side boxart, or
    keyboard (left/right arrows + Enter).

NEW (08/28 - part 10)
  - SD Card: new "carousel" view (game-card button next to icons/list) -
    boxart for each known ROM via the Libretro Thumbnails (RetroArch)
    community database. Requires internet (only to download images,
    never to talk to the cartridge); cached locally. Name matching
    between the ROM file and the database isn't guaranteed 100% for
    every game (different naming conventions) - a game not found just
    stays without an image. Click a boxart -> detail sheet (size,
    in-game screenshot) with Play and Download buttons.

FIX (08/28 - part 9)
  - Rename/Delete (SD Card context menu) did nothing: two distinct bugs
    fixed (a missing call argument for Rename; the native confirm()/
    prompt() dialogs aren't reliable in this kind of application -
    replaced with a homemade window, throughout the program).

FIX (08/28 - part 8)
  - SD Card: the context menu (right-click) never showed up, neither in
    icon nor list view - fixed. Double-click now launches the game
    (instead of downloading it); download remains available via the
    arrow button or the context menu.

NEW (08/28 - part 7)
  - SD Card: right-click a file -> context menu with Play, Rename,
    Download, Delete. Note: there is no native rename in the protocol
    (no known cartridge/tool has one), so "Rename" does a full copy +
    deletion of the original (a bit slower than a real rename,
    especially on a large ROM).

FIX (08/28 - part 6)
  - Screen capture: if the cartridge's menu isn't displayed (a game is
    running), a clear message instead of a raw timeout. Verified by
    reverse engineering: the *v protocol itself is already correct, no
    bug.

FIX (08/28 - part 5)
  - SD Card: the current folder now refreshes after an upload
    (drag-and-drop or Import button), in a single refresh even for
    several files at once.

FIX (08/28 - part 4)
  - "SD Card" listing: FIXED. Thanks to a reverse engineering of
    turbolink.exe provided by the user, we found that CMD_F_DIR_RD was
    expecting an argument (u16, max name length) that was never sent -
    the firmware stayed stuck waiting for it, hence the total silence
    observed. To be retested on the real cartridge for final
    confirmation.

FIX (08/28 - part 3)
  - "SD Card" listing: refined diagnosis (see below, now resolved).

FIX (08/28 - part 2)
  - Sprites: zoom made the tiles blurry (bilinear smoothing) instead of
    crisp raw pixels. Fixed (pixelated image-rendering guaranteed at any
    zoom level).

FIX (real hardware feedback, 08/28 - follow-up)
  - The log (bottom of the window) didn't allow selecting/copying text on
    Windows (the app disables text selection everywhere in the window, to
    avoid triggering it by mistake while dragging the splitter or
    selecting sprites; Windows/WebView2 enforces this rule more strictly
    than macOS). The log is now an exception: text there selects and
    copies normally.

IMPORTANT FIX (real hardware feedback, 08/28)
  - "Launch a game" broke the serial port for the rest of the session
    (screen capture, memory, VRAM/CRAM then failed with "The device does
    not recognize the command", os error 22): waiting for the console
    reset used a serial call poorly supported by the cartridge's USB-CDC
    driver. Replaced with a classic blocking read. Fixed.
  - Safety net added: if the serial port becomes unusable during a
    session (whatever the cause), the app detects the failure and
    switches back to "Disconnected" instead of repeating the same error
    in a loop - just click Connect again.
  - "SD Card" listing (systematic timeout): confirmed bug on this
    cartridge, NOT YET FIXED - the reconstructed protocol
    (CMD_F_DIR_OPN/RD) doesn't match what a real Turbo EverDrive Pro
    responds. To help fix it: run from a command prompt, next to
    edlink-cli.exe:
      set EDLINK_TRACE=1
      edlink-cli.exe --port COM3 ls sd:/ > trace.txt 2>&1
    (adjust COM3) then send trace.txt.

QA TEST CHECKLIST
  qa-checklist.html (next to this file): a standalone validation form to
  open in a browser, same theme as the app. Test grid with status/comment
  per row, screenshot attached per row (downloadable as a single .zip),
  Markdown report generation ready to paste into an email. No data is
  sent anywhere.

NOTE
  Cartridge functions require the cartridge's OS menu to be displayed and
  the console powered on.

Turbo Everdrive USB Tools GUI — build Windows x86_64
===================================================

(English version: README-EN.txt)

Version : 0.1.1-alpha (jalon M2)
Cible   : x86_64-pc-windows-gnu (PE32+)

La version exacte (numero + hash git + date) est affichee en bas de la barre
laterale de l'application et par "edlink-emulator.exe --version".

CONTENU DU DOSSIER
  edlink-app.exe        Interface graphique (Tauri / WebView2)
  edlink-cli.exe        Ligne de commande (voir LISEZ-MOI.txt)
  WebView2Loader.dll    Requis a cote de edlink-app.exe
  README.txt            Ce fichier
  LISEZ-MOI.txt         Aide de edlink-cli.exe
  GUIDE_UTILISATEUR.md     Guide pas à pas pour l'application (français)
  GUIDE_UTILISATEUR.en.md  Guide pas à pas pour l'application (anglais)

PREREQUIS
  - Windows 10/11 64 bits.
  - WebView2 Runtime : preinstalle sur Windows 10/11 recents
    (sinon : https://developer.microsoft.com/microsoft-edge/webview2/).

UTILISATION
  - Garder edlink-app.exe et WebView2Loader.dll dans le meme dossier.
  - Lancer edlink-app.exe.
  - Connexion : brancher la Turbo EverDrive en USB, choisir le port COM
    (ou "auto"), cliquer Connecter. Pour l'emulateur virtuel EdLink,
    saisir le port dans le champ "Port manuel".

CE QU'IL Y A DANS CETTE VERSION (M2)
  - Onglet "Carte SD" : explorateur (listing via le protocole FS du firmware
    Pro), envoi / telechargement avec barre de progression, interface reactive.
  - Onglet Jouer simplifie : "Choisir et lancer..." deploie puis lance
    directement la ROM.
  - Reset console, capture d'ecran du menu.
  - Visualiseur memoire (lecture seule).
      RAM : sur une vraie carte, chaque lecture parcourt le bus cartouche et
        gele brievement le CPU PC-Engine -> mode conservateur (petits blocs,
        lecture a la demande via "Rafraichir"). Libre sur l'emulateur.
      VRAM / CRAM : instantane via le menu de la carte (commande *v, comme la
        capture d'ecran) -> affichez le menu de la carte, pas pendant un jeu.
  - Onglet Sprites : planche de tuiles decodees de la VRAM (8x8 fond ou les
    6 tailles de sprite du VDC, 16x16 a 32x64), choix de palette, zoom ; clic
    -> adresse VRAM, ou glisser pour selectionner une plage (export PNG de
    la seule selection ; "Echap" ou le bouton dedie l'efface).
  - La capture d'ecran ne relit plus la carte quand on bouge un reglage : c'est
    un rendu logiciel du plan de tuiles (pas de sprites, pas d'effets par ligne).
  - Correctif important : toute sauvegarde/telechargement (SD, capture d'ecran,
    dump memoire, export sprites) echouait silencieusement depuis la toute
    premiere version (bug d'argument Tauri). Corrige dans cette build.
  - Sprites : bouton "Locker" -> recadre la vue sur la seule selection (le
    reste de la VRAM est masque). Pratique pour suivre un sprite au fil de
    plusieurs "Capturer" (animation) sans le reperdre dans la planche ; la
    selection reste posee sur la meme zone VRAM meme en changeant la taille
    de cellule ou le nombre de colonnes.

NOUVEAU (31/08)
  - Interface disponible en francais, anglais, allemand et espagnol
    (selecteur de langue en haut a droite).
  - GAMES : nouvelle source de pochettes au choix, en plus du reseau
    (Libretro Thumbnails) - un dossier local "DB_Thumbnails" choisi sur le
    disque (bouton dossier a cote du menu deroulant), fonctionnant hors
    ligne, avec la structure Named_Boxarts/Named_Snaps/Named_Titles.
  - GAMES : catégorie virtuelle "GAMES" qui apparait automatiquement si le
    dossier de base ne contient aucun sous-dossier categorie (acces direct
    aux ROM posees a la racine, plus de message d'erreur bloquant).
  - GAMES : nouveau bouton favoris (coeur) dans la fiche de detail d'un jeu
    - catégorie virtuelle "Favoris" toujours presente en tete de liste,
    regroupant les jeux marques quelle que soit leur categorie reelle.

NOUVEAU (28/08 - suite 20)
  - Fiche de detail d'un jeu : alterne desormais l'ecran-titre et la
    capture en jeu toutes les 2 secondes quand les deux sont disponibles
    (badge indiquant lequel est affiche).
  - Emulateur (dev/tests, hors build Windows) : n'affiche plus le message
    de deconnexion en boucle.

NOUVEAU (28/08 - suite 22)
  - Fiche de detail : bouton "C'est le bon jeu" quand la pochette vient
    d'une correspondance approchee - memorise le titre trouve pour ce
    fichier (confiance 100% ensuite, sans repasser par la recherche
    approchee). Le bandeau reste affiche tant que la souris est dessus.

NOUVEAU/CORRECTIF (28/08 - suite 21)
  - Fiche de detail : l'avertissement "pochette approchee" s'efface tout
    seul apres 3s au lieu de rester affiche en permanence.
  - Alternance ecran-titre/capture reglee a 2s (au lieu de 1s).
  - qa-checklist.html : garde l'image d'origine jointe (plus de
    redimensionnement/reencodage JPEG automatique).
  - Nouveau : docs/GUIDE_UTILISATEUR.md, guide pas a pas pour l'utilisateur
    final (installation, chaque onglet en detail, depannage courant).

CORRECTIF (28/08 - suite 19)
  - Jaquettes : la recherche approchee compare desormais aussi separement
    chaque cote d'un titre "Principal - Sous-titre" (tres courant sur PC
    Engine japonais) - le nom du dump ROM correspond souvent a un seul des
    deux cotes. Corrige au passage un risque de faux positif sur un mot
    commun court entre plusieurs jeux differents.

CORRECTIF (28/08 - suite 18)
  - Jaquettes : corrige les titres japonais prefixes cote Libretro (ex.
    "Cyber Cross (J).pce" -> "Busou Keiji - Cyber Cross (Japan)", non
    trouve avant, trouve a 100% maintenant). Badge de pourcentage
    desormais visible en permanence sur la vignette (pas seulement au
    survol) quand ce n'est pas une correspondance exacte.

NOUVEAU (28/08 - suite 17)
  - Jaquettes : recherche approchee (au plus proche, evaluee en %) en repli
    quand aucune variante exacte de nom ne correspond - contre l'index
    complet de la base Libretro, seuil 80% de similarite minimum. La fiche
    de detail affiche le titre trouve et son score quand ce n'est pas une
    correspondance exacte, avec un renvoi vers la roue crantee (mapping
    manuel) en cas d'erreur.

CORRECTIF (28/08 - suite 16)
  - GAMES : le bouton "Jouer" de la fiche de detail ne lancait rien - chemin
    "sd:/" duplique (sd:/sd:/...) construit par erreur. Corrige et verifie
    contre l'emulateur.

NOUVEAU/CORRECTIF (28/08 - suite 15)
  - GAMES : rangees de categories reduites de 30%.
  - GAMES : corrige un bug ou les pochettes disparaissaient (icone manette
    seule) en revisitant une categorie deja vue.
  - GAMES : bouton roue crantee (survol d'une vignette) pour associer
    manuellement un jeu non trouve a un titre exact de la base de
    pochettes (Libretro Thumbnails). Memorise pour les prochaines fois.

NOUVEAU (28/08 - suite 14)
  - GAMES devient un onglet a part entiere (icone manette, juste sous
    Connexion) au lieu d'etre une vue dans Carte SD.
  - Corrige la fiche de detail d'un jeu : la capture d'ecran etait tronquee
    (hauteur trop limitee) - se voit desormais en entier.

CORRECTIF (28/08 - suite 13)
  - Vue Jeux : la mosaique reprend maintenant le degrade de couleur de sa
    categorie (au lieu du fond sombre) - texte/bouton adaptes pour rester
    lisibles.

NOUVEAU (28/08 - suite 12)
  - Vue "Jeux" (bouton carte a jouer) refaite : dossier de base configurable
    (par defaut sd:/GAMES, memorise), arborescence attendue
    sd:/GAMES/<Categorie>/<ROM>. Liste des categories en rangees colorees
    (style Recalbox), gros texte ; clic sur une categorie -> mosaique des
    jeux avec pochette, clic sur un jeu -> fiche detaillee (Jouer/
    Telecharger). Bouton "Changer le dossier de jeux" pour modifier le
    chemin.

NOUVEAU (28/08 - suite 11)
  - Carrousel Carte SD : nouveau style "coverflow" (comme EmulationStation/
    Batocera) - la pochette du milieu est mise en avant, celles des cotes
    sont reduites et estompees. Navigation aux fleches, clic sur une
    pochette laterale, ou clavier (fleches gauche/droite + Entree).

NOUVEAU (28/08 - suite 10)
  - Carte SD : nouvelle vue "carrousel" (bouton carte a jouer a cote de
    icones/liste) - pochette de chaque ROM connue via la base communautaire
    Libretro Thumbnails (RetroArch). Necessite Internet (uniquement pour
    telecharger les images, jamais pour parler a la carte) ; mise en cache
    locale. La correspondance de nom entre le fichier ROM et la base n'est
    pas garantie a 100% pour tous les jeux (conventions de nommage
    differentes) - un jeu non trouve reste juste sans image.
    Clic sur une pochette -> fiche detaillee (taille, capture d'ecran du
    jeu) avec boutons Jouer et Telecharger.

CORRECTIF (28/08 - suite 9)
  - Renommer/Effacer (menu contextuel Carte SD) ne faisaient rien : deux bugs
    distincts corriges (argument d'appel manquant pour Renommer ; les boites
    de dialogue natives confirm()/prompt() ne sont pas fiables dans ce type
    d'application - remplacees par une fenetre maison, dans tout le
    programme).

CORRECTIF (28/08 - suite 8)
  - Carte SD : le menu contextuel (clic droit) ne s'affichait jamais, ni en
    icones ni en liste - corrige. Le double-clic lance desormais le jeu
    (au lieu de le telecharger) ; le telechargement reste accessible via
    le bouton fleche ou le menu contextuel.

NOUVEAU (28/08 - suite 7)
  - Carte SD : clic droit sur un fichier -> menu contextuel avec Jouer,
    Renommer, Telecharger, Effacer. Attention : pas de renommage natif dans
    le protocole (aucune carte/outil connu n'en a un), donc "Renommer" fait
    une copie complete + suppression de l'original (un peu plus lent qu'un
    vrai renommage, surtout sur une grosse ROM).

CORRECTIF (28/08 - suite 6)
  - Capture d'ecran : si le menu de la carte n'est pas affiche (partie en
    cours), message clair au lieu du timeout brut. Verifie par reverse
    engineering : le protocole *v lui-meme est deja correct, sans bug.

CORRECTIF (28/08 - suite 5)
  - Carte SD : le dossier courant se rafraichit desormais apres un upload
    (glisser-deposer ou bouton Importer), en un seul rafraichissement meme
    pour plusieurs fichiers a la fois.

CORRECTIF (28/08 - suite 4)
  - Listing "Carte SD" : CORRIGE. Grace a un reverse engineering de
    turbolink.exe fourni par l'utilisateur, on a trouve que CMD_F_DIR_RD
    attendait un argument (u16, longueur max de nom) jamais envoye - le
    firmware restait bloque a l'attendre, d'ou le silence total observe.
    A retester sur la vraie carte pour confirmation finale.

CORRECTIF (28/08 - suite 3)
  - Listing "Carte SD" : diagnostic affine (voir plus bas, desormais resolu).

CORRECTIF (28/08 - suite 2)
  - Sprites : le zoom rendait les tuiles floues (lissage bilineaire) au lieu
    de pixels bruts nets. Corrige (image-rendering pixelise garanti a
    n'importe quel niveau de zoom).

CORRECTIF (retour matos reel, 28/08 - suite)
  - Le journal (bas de fenetre) ne permettait pas de selectionner/copier le
    texte sous Windows (l'appli desactive la selection de texte partout dans
    la fenetre, pour eviter d'en declencher par erreur en glissant le
    separateur ou en selectionnant des sprites ; Windows/WebView2 applique
    cette regle plus strictement que macOS). Le journal fait desormais
    exception : le texte s'y selectionne et se copie normalement.

CORRECTIF IMPORTANT (retour matos reel, 28/08)
  - "Lancer un jeu" plantait le port serie pour tout le reste de la session
    (capture d'ecran, memoire, VRAM/CRAM echouaient ensuite avec "The device
    does not recognize the command", os error 22) : l'attente du reset de la
    console utilisait un appel serie mal supporte par le pilote USB-CDC de la
    carte. Remplace par une lecture bloquante classique. Corrige.
  - Filet de securite ajoute : si le port serie devient inutilisable en cours
    de session (quelle qu'en soit la cause), l'appli detecte l'echec et
    repasse en "Deconnecte" au lieu de repeter la meme erreur en boucle -
    il suffit de cliquer Connecter a nouveau.
  - Listing "Carte SD" (timeout systematique) : bug confirme sur cette carte,
    PAS ENCORE CORRIGE - le protocole reconstitue (CMD_F_DIR_OPN/RD) ne
    correspond pas a ce que repond une vraie Turbo EverDrive Pro. Pour aider
    a le corriger : lancer depuis une invite de commandes, a cote de
    edlink-cli.exe :
      set EDLINK_TRACE=1
      edlink-cli.exe --port COM3 ls sd:/ > trace.txt 2>&1
    (adapter COM3) puis envoyer trace.txt.

GRILLE DE TEST (QA)
  qa-checklist.html (a cote de ce fichier) : formulaire de validation
  autonome a ouvrir dans un navigateur, meme theme que l'application. Grille
  de tests avec statut/commentaire par ligne, capture d'ecran jointe par
  ligne (telechargeable en un seul .zip), generation d'un rapport Markdown
  pret a coller dans un e-mail. Aucune donnee envoyee nulle part.

NOTE
  Les fonctions carte necessitent le menu OS de la cartouche affiche et
  la console alimentee.
